# This is a sample Python script.

# Press Shift+F10 to execute it or replace it with your code.
# Press Double Shift to search everywhere for classes, files, tool windows, actions, and settings.
import math
'''
mat1 = [1, 0, 0, 0], [0, -0.707, 0.707, 0.707], [0, -0.707, -0.707, 1], [0, 0, 0, 1]
mat2 = [-1, 0, 0, 0], [0, 0.707, -0.707, -0.56], [0, -0.707, -0.707, 1.268], [0, 0, 0, 1]
def mnozenje_matrica (mat1 , mat2):
    #mat3= [(mat1[0][0]*mat2[0][0]+mat1[0][1]*mat2[1][0]+mat1[0][2]*mat2[2][0]+mat1[0][3]*mat2[3][0]), ()]
    return mat3
'''

mat1 = [1, 0, 0, 0], [0, -0.707, 0.707, 0.707], [0, -0.707, -0.707, 1], [0, 0, 0, 1]
mat2 = [-1, 0, 0, 0], [0, 0.707, -0.707, -0.56], [0, -0.707, -0.707, 1.268], [0, 0, 0, 1]
list_0 = mat1[0][0:4]

for i in range(list_0):
    for j in range(mat2[0:4][0]):
        print(i*j)

izraz=(0-0)**2+(0.707+0.56)**2+(1-1.268)**2+(1-1)**2
def distanca(izraz):
    return sqrt(izraz)

